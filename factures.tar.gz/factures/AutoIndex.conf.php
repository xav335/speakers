<?php

/* AutoIndex PHP Script config file

base_dir	./
icon_path	index_icons/winxp/
language	fr
template	./templates/default/
log_file	false
description_file	false
user_list	.htpasswd.autoindex
download_count	false
hidden_files	hidden_files
banned_list	false
show_dir_size	true
use_login_system	true
force_download	false
search_enabled	true
anti_leech	false
must_login_to_download	false
archive	false
parse_htaccess	true
days_new	0
thumbnail_height	0
bandwidth_limit	0
md5_show	0
entries_per_page	0

*/

?>